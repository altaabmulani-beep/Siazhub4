
import { Product, Review } from './types';

export const CATEGORIES = [
  { name: 'Clothing', icon: '👕', image: 'https://images.unsplash.com/photo-1490481651871-ab68624d5517?auto=format&fit=crop&q=80&w=600' },
  { name: 'Jewelry', icon: '💍', image: 'https://images.unsplash.com/photo-1515562141207-7a18b5ce3377?auto=format&fit=crop&q=80&w=600' },
  { name: 'Electronics', icon: '💻', image: 'https://images.unsplash.com/photo-1498049794561-7780e7231661?auto=format&fit=crop&q=80&w=600' },
  { name: 'Perfumes', icon: '🧴', image: 'https://images.unsplash.com/photo-1541643600914-78b084683601?auto=format&fit=crop&q=80&w=600' },
  { name: 'Shoes', icon: '👟', image: 'https://images.unsplash.com/photo-1533867617858-e7b97e060509?auto=format&fit=crop&q=80&w=600' },
  { name: 'Accessories', icon: '⌚', image: 'https://images.unsplash.com/photo-1524592094714-0f0654e20314?auto=format&fit=crop&q=80&w=600' },
];

export const PRODUCTS: Product[] = [
  {
    id: '1',
    name: 'Silk Evening Gown',
    price: 68000,
    oldPrice: 95000,
    category: 'Clothing',
    image: 'https://images.unsplash.com/photo-1595777457583-95e059d581b8?auto=format&fit=crop&q=80&w=400',
    rating: 4.8,
    reviewsCount: 24,
    affiliateUrl: 'https://amazon.com',
    platform: 'Amazon',
    isFlashDeal: true,
  },
  {
    id: '2',
    name: 'Diamond Solitaire Ring',
    price: 280000,
    category: 'Jewelry',
    image: 'https://images.unsplash.com/photo-1605100804763-247f67b3557e?auto=format&fit=crop&q=80&w=400',
    rating: 5.0,
    reviewsCount: 12,
    affiliateUrl: 'https://amazon.com',
    platform: 'Amazon',
    isBestSeller: true,
  },
  {
    id: '3',
    name: 'Midnight Oud Parfum',
    price: 18500,
    category: 'Perfumes',
    image: 'https://images.unsplash.com/photo-1541643600914-78b084683601?auto=format&fit=crop&q=80&w=400',
    rating: 4.9,
    reviewsCount: 89,
    affiliateUrl: 'https://flipkart.com',
    platform: 'Flipkart',
    isBestSeller: true,
  },
  {
    id: '4',
    name: 'OLED Smart TV 65"',
    price: 189000,
    oldPrice: 220000,
    category: 'Electronics',
    image: 'https://images.unsplash.com/photo-1593359677879-a4bb92f829d1?auto=format&fit=crop&q=80&w=400',
    rating: 4.7,
    reviewsCount: 156,
    affiliateUrl: 'https://amazon.com',
    platform: 'Amazon',
    isFlashDeal: true,
  },
  {
    id: '5',
    name: 'Handcrafted Oxford Shoes',
    price: 42000,
    category: 'Shoes',
    image: 'https://images.unsplash.com/photo-1533867617858-e7b97e060509?auto=format&fit=crop&q=80&w=400',
    rating: 4.6,
    reviewsCount: 43,
    affiliateUrl: 'https://amazon.com',
    platform: 'Amazon',
  },
  {
    id: '6',
    name: 'Ultra Premium Headphones',
    price: 45000,
    category: 'Electronics',
    image: 'https://images.unsplash.com/photo-1505740420928-5e560c06d30e?auto=format&fit=crop&q=80&w=400',
    rating: 4.9,
    reviewsCount: 67,
    affiliateUrl: 'https://flipkart.com',
    platform: 'Flipkart',
    isBestSeller: true,
  }
];

export const REVIEWS: Review[] = [
  {
    id: 'r1',
    user: 'Ananya Sharma',
    rating: 5,
    comment: 'Luxury redefined. This platform curate the best of Amazon products with an elegant touch.',
    avatar: 'https://i.pravatar.cc/150?u=ananya'
  },
  {
    id: 'r2',
    user: 'Vikram Malhotra',
    rating: 5,
    comment: 'The tech selection is top-notch. I saved 20% by following their flash deals.',
    avatar: 'https://i.pravatar.cc/150?u=vikram'
  }
];
