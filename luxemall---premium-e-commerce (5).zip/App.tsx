
import React from 'react';
import { ShopProvider } from './ShopContext';
import Navbar from './components/Navbar';
import Hero from './components/Hero';
import CategoryGrid from './components/CategoryGrid';
import ProductGrid from './components/ProductGrid';
import FlashDeals from './components/FlashDeals';
import Reviews from './components/Reviews';
import Newsletter from './components/Newsletter';
import Footer from './components/Footer';
import EliteConcierge from './components/EliteConcierge';
import BespokeStudio from './components/BespokeStudio';
import AffiliateProgram from './components/AffiliateProgram';
import MobileBottomNav from './components/MobileBottomNav';
import CartDrawer from './components/CartDrawer';

const App: React.FC = () => {
  return (
    <ShopProvider>
      <div className="min-h-screen flex flex-col selection:bg-beige-200 selection:text-charcoal-900 pb-20 md:pb-0">
        <Navbar />
        <main className="flex-grow">
          <Hero />
          
          {/* SEO Anchor */}
          <section className="bg-white py-12 text-center border-b border-beige-100">
            <div className="max-w-3xl mx-auto px-6">
               <h2 className="text-[10px] uppercase tracking-[0.5em] text-beige-800 font-bold mb-4">Elite Partner Network</h2>
               <p className="font-serif italic text-xl text-charcoal-800 leading-relaxed">
                 "LuxeMall provides direct access to high-fashion and premium tech deals through our verified Amazon and Flipkart associate channels."
               </p>
            </div>
          </section>

          <CategoryGrid />

          <div id="new">
            <ProductGrid />
          </div>

          <BespokeStudio />

          <AffiliateProgram />

          <FlashDeals />

          <Reviews />

          <Newsletter />
        </main>
        <Footer />
        
        {/* Overlays & Mobile Elements */}
        <CartDrawer />
        <MobileBottomNav />
        <EliteConcierge />
      </div>
    </ShopProvider>
  );
};

export default App;
