
import React, { useState } from 'react';
import { CATEGORIES } from '../constants';
import { useShop } from '../ShopContext';

const Navbar: React.FC = () => {
  const [isMenuOpen, setIsMenuOpen] = useState(false);
  const [isSearchVisible, setIsSearchVisible] = useState(false);
  const { cart, setIsCartOpen } = useShop();

  const cartCount = cart.reduce((acc, item) => acc + item.quantity, 0);

  return (
    <nav className="sticky top-0 z-50 bg-white/90 backdrop-blur-md border-b border-beige-200">
      <div className="max-w-7xl mx-auto px-6">
        <div className="flex justify-between items-center h-20">
          {/* Mobile Menu Toggle */}
          <div className="flex md:hidden">
            <button onClick={() => setIsMenuOpen(!isMenuOpen)} className="p-2 text-charcoal-700">
              <svg className="w-6 h-6" fill="none" stroke="currentColor" viewBox="0 0 24 24">
                <path strokeLinecap="round" strokeLinejoin="round" strokeWidth="2" d={isMenuOpen ? "M6 18L18 6M6 6l12 12" : "M4 6h16M4 12h16M4 18h16"} />
              </svg>
            </button>
          </div>

          {/* Logo */}
          <div className="flex-shrink-0 flex items-center">
            <h1 className="text-xl md:text-2xl font-serif font-bold tracking-[0.4em] text-charcoal-800 cursor-pointer">LUXEMALL</h1>
          </div>

          {/* Desktop Links */}
          <div className="hidden md:flex space-x-12 items-center">
            {['NEW', 'COLLECTIONS', 'FLASH DEALS', 'PARTNERS'].map(link => (
              <a 
                key={link} 
                href={link === 'FLASH DEALS' ? '#sale' : '#'} 
                className={`text-[10px] font-bold tracking-[0.3em] uppercase transition-colors ${link === 'FLASH DEALS' ? 'text-red-500' : 'text-gray-500 hover:text-charcoal-900'}`}
              >
                {link}
              </a>
            ))}
          </div>

          {/* Icons */}
          <div className="flex items-center space-x-4">
            <button 
              onClick={() => setIsSearchVisible(!isSearchVisible)}
              className="p-2 text-gray-600 hover:text-charcoal-900 transition-colors"
            >
              <svg className="w-5 h-5" fill="none" stroke="currentColor" viewBox="0 0 24 24"><path strokeLinecap="round" strokeLinejoin="round" strokeWidth="1.5" d="M21 21l-6-6m2-5a7 7 0 11-14 0 7 7 0 0114 0z" /></svg>
            </button>
            
            <button 
              onClick={() => setIsCartOpen(true)}
              className="relative p-2 text-gray-600 hover:text-charcoal-900 transition-colors"
              aria-label="Open cart"
            >
              <svg className="w-5 h-5" fill="none" stroke="currentColor" viewBox="0 0 24 24">
                <path strokeLinecap="round" strokeLinejoin="round" strokeWidth="1.5" d="M16 11V7a4 4 0 00-8 0v4M5 9h14l1 12H4L5 9z" />
              </svg>
              {cartCount > 0 && (
                <span className="absolute top-0 right-0 bg-charcoal-900 text-white text-[7px] w-4 h-4 flex items-center justify-center rounded-full font-bold shadow-sm">
                  {cartCount}
                </span>
              )}
            </button>

            <button className="hidden sm:block ml-2 px-6 py-3 border border-charcoal-800 text-[9px] font-bold tracking-[0.2em] uppercase hover:bg-charcoal-800 hover:text-white transition-all">
              Join Elite
            </button>
          </div>
        </div>
      </div>

      {/* Expandable Search */}
      {isSearchVisible && (
        <div className="bg-white border-b border-gray-100 p-8 absolute w-full animate-fade-in shadow-2xl">
          <div className="max-w-4xl mx-auto relative">
            <input 
              type="text" 
              placeholder="SEARCH CURATED DEALS..." 
              className="w-full border-b border-gray-300 focus:border-charcoal-800 outline-none py-4 text-2xl font-serif italic text-charcoal-900"
              autoFocus
            />
            <button className="absolute right-0 top-6 text-gray-400 hover:text-charcoal-800" onClick={() => setIsSearchVisible(false)}>
              <svg className="w-8 h-8" fill="none" stroke="currentColor" viewBox="0 0 24 24"><path strokeLinecap="round" strokeLinejoin="round" strokeWidth="1" d="M6 18L18 6M6 6l12 12" /></svg>
            </button>
          </div>
        </div>
      )}
    </nav>
  );
};

export default Navbar;
