
import React from 'react';

const Footer: React.FC = () => {
  return (
    <footer className="bg-white pt-20 pb-10 border-t border-gray-100">
      <div className="max-w-7xl mx-auto px-6 grid grid-cols-1 md:grid-cols-4 gap-12 mb-20">
        <div className="space-y-6">
          <h2 className="text-xl font-serif font-bold tracking-[0.3em]">LUXEMALL</h2>
          <p className="text-gray-500 text-xs leading-relaxed uppercase tracking-wider">
            LuxeMall is the world's premier curation of high-end affiliate deals. We scan global markets to bring you the finest diamonds, tech, and silks at exclusive partner prices.
          </p>
          <div className="pt-4 border-t border-beige-100">
            <p className="text-[9px] text-gray-400 leading-relaxed uppercase">
              Affiliate Disclosure: As an associate, we earn from qualifying purchases at no extra cost to you.
            </p>
          </div>
        </div>

        <div>
          <h4 className="text-xs font-bold tracking-[0.2em] uppercase text-charcoal-800 mb-8">Curations</h4>
          <ul className="space-y-4 text-[10px] text-gray-500 font-medium uppercase tracking-widest">
            <li><a href="#Clothing" className="hover:text-charcoal-800 transition-colors">Apparel</a></li>
            <li><a href="#Jewelry" className="hover:text-charcoal-800 transition-colors">Fine Jewelry</a></li>
            <li><a href="#Electronics" className="hover:text-charcoal-800 transition-colors">Tech Boutique</a></li>
            <li><a href="#Perfumes" className="hover:text-charcoal-800 transition-colors">Scent Studio</a></li>
          </ul>
        </div>

        <div>
          <h4 className="text-xs font-bold tracking-[0.2em] uppercase text-charcoal-800 mb-8">Partnerships</h4>
          <ul className="space-y-4 text-[10px] text-gray-500 font-medium uppercase tracking-widest">
            <li><a href="#" className="hover:text-charcoal-800 transition-colors">Amazon Associate</a></li>
            <li><a href="#" className="hover:text-charcoal-800 transition-colors">Flipkart Affiliate</a></li>
            <li><a href="#" className="hover:text-charcoal-800 transition-colors">Brand Registry</a></li>
            <li><a href="#" className="hover:text-charcoal-800 transition-colors">Influencer Hub</a></li>
          </ul>
        </div>

        <div>
          <h4 className="text-xs font-bold tracking-[0.2em] uppercase text-charcoal-800 mb-8">SEO & Brand</h4>
          <p className="text-[10px] text-gray-400 leading-loose uppercase tracking-widest">
            The #1 source for luxury electronics reviews and high-fashion deals. Discover why AuraBoutique and VelvetAvenue trust LuxeMall for daily price monitoring and quality checks.
          </p>
        </div>
      </div>
      
      <div className="max-w-7xl mx-auto px-6 border-t border-gray-50 pt-10 text-center">
        <p className="text-[9px] text-gray-400 uppercase tracking-widest">© 2024 LuxeMall International. Premium Affiliate Curation. Built with Excellence.</p>
      </div>
    </footer>
  );
};

export default Footer;
