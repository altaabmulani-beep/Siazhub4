import React, { useState, useRef, useEffect, useCallback } from 'react';
import { GoogleGenAI, LiveServerMessage, Modality } from '@google/genai';
import { useShop } from '../ShopContext';

const EliteConcierge: React.FC = () => {
  const { isAmbassador } = useShop();
  const [isOpen, setIsOpen] = useState(false);
  const [isActive, setIsActive] = useState(false);
  const [transcriptions, setTranscriptions] = useState<{ role: 'user' | 'concierge', text: string }[]>([]);
  const [currentInput, setCurrentInput] = useState('');
  const [currentOutput, setCurrentOutput] = useState('');

  const audioContextRef = useRef<AudioContext | null>(null);
  const outAudioContextRef = useRef<AudioContext | null>(null);
  const streamRef = useRef<MediaStream | null>(null);
  const sessionRef = useRef<any>(null);
  const nextStartTimeRef = useRef<number>(0);
  const sourcesRef = useRef<Set<AudioBufferSourceNode>>(new Set());

  // Use refs for transcriptions to avoid stale closures in Live API callbacks
  const currentInputRef = useRef('');
  const currentOutputRef = useRef('');

  // Base64 helper methods
  const encode = (bytes: Uint8Array) => {
    let binary = '';
    const len = bytes.byteLength;
    for (let i = 0; i < len; i++) binary += String.fromCharCode(bytes[i]);
    return btoa(binary);
  };

  const decode = (base64: string) => {
    const binaryString = atob(base64);
    const len = binaryString.length;
    const bytes = new Uint8Array(len);
    for (let i = 0; i < len; i++) bytes[i] = binaryString.charCodeAt(i);
    return bytes;
  };

  const decodeAudioData = async (data: Uint8Array, ctx: AudioContext, sampleRate: number, numChannels: number) => {
    const dataInt16 = new Int16Array(data.buffer);
    const frameCount = dataInt16.length / numChannels;
    const buffer = ctx.createBuffer(numChannels, frameCount, sampleRate);
    for (let channel = 0; channel < numChannels; channel++) {
      const channelData = buffer.getChannelData(channel);
      for (let i = 0; i < frameCount; i++) {
        channelData[i] = dataInt16[i * numChannels + channel] / 32768.0;
      }
    }
    return buffer;
  };

  const startSession = async () => {
    try {
      // Create a new GoogleGenAI instance right before making an API call
      const ai = new GoogleGenAI({ apiKey: process.env.API_KEY });
      audioContextRef.current = new (window.AudioContext || (window as any).webkitAudioContext)({ sampleRate: 16000 });
      outAudioContextRef.current = new (window.AudioContext || (window as any).webkitAudioContext)({ sampleRate: 24000 });
      
      const stream = await navigator.mediaDevices.getUserMedia({ audio: true });
      streamRef.current = stream;

      const sessionPromise = ai.live.connect({
        model: 'gemini-2.5-flash-native-audio-preview-12-2025',
        callbacks: {
          onopen: () => {
            setIsActive(true);
            const source = audioContextRef.current!.createMediaStreamSource(stream);
            const scriptProcessor = audioContextRef.current!.createScriptProcessor(4096, 1, 1);
            scriptProcessor.onaudioprocess = (e) => {
              const inputData = e.inputBuffer.getChannelData(0);
              const l = inputData.length;
              const int16 = new Int16Array(l);
              for (let i = 0; i < l; i++) int16[i] = inputData[i] * 32768;
              const pcmBlob = {
                data: encode(new Uint8Array(int16.buffer)),
                mimeType: 'audio/pcm;rate=16000',
              };
              // Always use sessionPromise.then to ensure it is sending to the current active session
              sessionPromise.then(s => s.sendRealtimeInput({ media: pcmBlob }));
            };
            source.connect(scriptProcessor);
            scriptProcessor.connect(audioContextRef.current!.destination);
          },
          onmessage: async (message: LiveServerMessage) => {
            if (message.serverContent?.outputTranscription) {
              const text = message.serverContent.outputTranscription.text;
              currentOutputRef.current += text;
              setCurrentOutput(currentOutputRef.current);
            } else if (message.serverContent?.inputTranscription) {
              const text = message.serverContent.inputTranscription.text;
              currentInputRef.current += text;
              setCurrentInput(currentInputRef.current);
            }

            // Fix stale closures and TypeScript error by using typed local variables from refs
            if (message.serverContent?.turnComplete) {
              const input = currentInputRef.current;
              const output = currentOutputRef.current;
              
              setTranscriptions(prev => {
                const newItems: { role: 'user' | 'concierge', text: string }[] = [
                  { role: 'user', text: input },
                  { role: 'concierge', text: output }
                ];
                return [...prev, ...newItems].filter(t => t.text.trim() !== '');
              });
              
              currentInputRef.current = '';
              currentOutputRef.current = '';
              setCurrentInput('');
              setCurrentOutput('');
            }

            const base64Audio = message.serverContent?.modelTurn?.parts[0]?.inlineData?.data;
            if (base64Audio && outAudioContextRef.current) {
              nextStartTimeRef.current = Math.max(nextStartTimeRef.current, outAudioContextRef.current.currentTime);
              const audioBuffer = await decodeAudioData(decode(base64Audio), outAudioContextRef.current, 24000, 1);
              const source = outAudioContextRef.current.createBufferSource();
              source.buffer = audioBuffer;
              source.connect(outAudioContextRef.current.destination);
              source.start(nextStartTimeRef.current);
              nextStartTimeRef.current += audioBuffer.duration;
              sourcesRef.current.add(source);
              source.onended = () => sourcesRef.current.delete(source);
            }

            if (message.serverContent?.interrupted) {
              sourcesRef.current.forEach(s => s.stop());
              sourcesRef.current.clear();
              nextStartTimeRef.current = 0;
            }
          },
          onclose: () => setIsActive(false),
          onerror: (e) => console.error('Concierge Error:', e),
        },
        config: {
          responseModalities: [Modality.AUDIO],
          speechConfig: { voiceConfig: { prebuiltVoiceConfig: { voiceName: 'Charon' } } },
          systemInstruction: `You are the Elite Concierge for LuxeMall, an ultra-premium marketplace. 
          Your voice should be calm, sophisticated, and helpful. 
          You help clients find products, check stock, and provide fashion advice.
          Current client status: ${isAmbassador ? 'Elite Brand Ambassador' : 'Valued Client'}.`,
          outputAudioTranscription: {},
          inputAudioTranscription: {},
        }
      });
      sessionRef.current = await sessionPromise;
    } catch (err) {
      console.error('Failed to start concierge:', err);
    }
  };

  const stopSession = () => {
    sessionRef.current?.close();
    streamRef.current?.getTracks().forEach(track => track.stop());
    audioContextRef.current?.close();
    outAudioContextRef.current?.close();
    setIsActive(false);
  };

  const toggleConcierge = () => {
    if (isOpen) {
      stopSession();
      setIsOpen(false);
    } else {
      setIsOpen(true);
    }
  };

  return (
    <>
      {/* Floating Action Button */}
      <button 
        onClick={toggleConcierge}
        className={`fixed bottom-24 md:bottom-8 right-6 z-[55] w-14 h-14 rounded-full flex items-center justify-center transition-all duration-500 shadow-2xl group ${isOpen ? 'bg-charcoal-900 text-white rotate-90' : 'bg-white text-charcoal-800 border border-beige-200 hover:border-charcoal-800'}`}
      >
        {isOpen ? (
          <svg className="w-6 h-6" fill="none" stroke="currentColor" viewBox="0 0 24 24"><path strokeLinecap="round" strokeLinejoin="round" strokeWidth="2" d="M6 18L18 6M6 6l12 12" /></svg>
        ) : (
          <div className="relative">
            <svg className="w-6 h-6" fill="none" stroke="currentColor" viewBox="0 0 24 24"><path strokeLinecap="round" strokeLinejoin="round" strokeWidth="1.5" d="M8 10h.01M12 10h.01M16 10h.01M9 16H5a2 2 0 01-2-2V6a2 2 0 012-2h14a2 2 0 012 2v8a2 2 0 01-2 2h-5l-5 5v-5z" /></svg>
            <span className="absolute -top-1 -right-1 flex h-2 w-2">
              <span className="animate-ping absolute inline-flex h-full w-full rounded-full bg-beige-400 opacity-75"></span>
              <span className="relative inline-flex rounded-full h-2 w-2 bg-beige-600"></span>
            </span>
          </div>
        )}
      </button>

      {/* Concierge Panel */}
      {isOpen && (
        <div className="fixed bottom-40 md:bottom-28 right-6 z-[55] w-[calc(100vw-3rem)] md:w-96 max-h-[70vh] flex flex-col bg-charcoal-900 text-white rounded-sm shadow-2xl border border-charcoal-800 animate-fade-in-up overflow-hidden">
          {/* Header */}
          <div className="p-6 border-b border-charcoal-800 flex items-center justify-between">
            <div className="flex items-center gap-3">
              <div className={`w-2 h-2 rounded-full ${isActive ? 'bg-green-500 animate-pulse' : 'bg-gray-600'}`} />
              <h3 className="font-serif italic text-lg tracking-wide">Elite Concierge</h3>
            </div>
            <span className="text-[8px] uppercase tracking-[0.3em] text-gray-400">Private Channel</span>
          </div>

          {/* Transcript Area */}
          <div className="flex-1 overflow-y-auto p-6 space-y-6 scrollbar-hide min-h-[300px]">
            {transcriptions.length === 0 && !currentInput && !currentOutput && (
              <div className="text-center py-12 space-y-4">
                <div className="w-12 h-12 border border-charcoal-800 rounded-full flex items-center justify-center mx-auto opacity-50">
                   <span className="text-xl">✨</span>
                </div>
                <p className="text-xs font-serif italic text-gray-500">"How may I assist your shopping journey today?"</p>
              </div>
            )}
            
            {transcriptions.map((t, idx) => (
              <div key={idx} className={`flex flex-col ${t.role === 'user' ? 'items-end' : 'items-start'}`}>
                <span className="text-[7px] uppercase tracking-widest text-gray-500 mb-1">{t.role}</span>
                <p className={`text-sm leading-relaxed max-w-[85%] font-serif ${t.role === 'user' ? 'text-beige-200' : 'text-white italic'}`}>
                  {t.text}
                </p>
              </div>
            ))}

            {(currentInput || currentOutput) && (
              <div className="space-y-4 pt-4 border-t border-charcoal-800/50">
                {currentInput && (
                  <div className="flex flex-col items-end opacity-70">
                    <span className="text-[7px] uppercase tracking-widest text-gray-500 mb-1">user</span>
                    <p className="text-sm font-serif text-beige-200">{currentInput}</p>
                  </div>
                )}
                {currentOutput && (
                  <div className="flex flex-col items-start">
                    <span className="text-[7px] uppercase tracking-widest text-gray-500 mb-1">concierge</span>
                    <p className="text-sm font-serif text-white italic animate-pulse">{currentOutput}</p>
                  </div>
                )}
              </div>
            )}
          </div>

          {/* Controls */}
          <div className="p-6 bg-charcoal-950 border-t border-charcoal-800">
            {isActive ? (
              <div className="flex flex-col items-center gap-4">
                <div className="flex items-center gap-1 h-8">
                  {[...Array(12)].map((_, i) => (
                    <div 
                      key={i} 
                      className="w-0.5 bg-beige-600 animate-bounce" 
                      style={{ 
                        height: `${Math.random() * 100}%`,
                        animationDelay: `${i * 0.1}s`,
                        animationDuration: '0.8s'
                      }} 
                    />
                  ))}
                </div>
                <button 
                  onClick={stopSession}
                  className="w-full py-3 border border-red-900/50 text-red-500 text-[9px] uppercase tracking-[0.3em] font-bold hover:bg-red-950/30 transition-all"
                >
                  End Consultation
                </button>
              </div>
            ) : (
              <button 
                onClick={startSession}
                className="w-full py-4 bg-white text-charcoal-900 text-[10px] uppercase tracking-[0.3em] font-bold hover:bg-beige-50 transition-all flex items-center justify-center gap-3"
              >
                <svg className="w-3 h-3" fill="currentColor" viewBox="0 0 20 20"><path fillRule="evenodd" d="M7 4a3 3 0 016 0v4a3 3 0 11-6 0V4zm4 10.93A7.001 7.001 0 0017 8a1 1 0 10-2 0A5 5 0 015 8a1 1 0 00-2 0 7.001 7.001 0 006 6.93V17H6a1 1 0 100 2h8a1 1 0 100-2h-3v-2.07z" clipRule="evenodd" /></svg>
                Speak with Concierge
              </button>
            )}
            <p className="text-[7px] text-gray-600 uppercase tracking-widest text-center mt-4">
              Encrypted Real-time Voice Link
            </p>
          </div>
        </div>
      )}
    </>
  );
};

export default EliteConcierge;