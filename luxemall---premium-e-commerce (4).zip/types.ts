
export type Category = 'Clothing' | 'Jewelry' | 'Electronics' | 'Perfumes' | 'Shoes' | 'Accessories';

export interface Product {
  id: string;
  name: string;
  price: number;
  oldPrice?: number;
  category: Category;
  image: string;
  rating: number;
  reviewsCount: number;
  affiliateUrl: string; // The URL to redirect users to
  platform: 'Amazon' | 'Flipkart' | 'Direct';
  isFlashDeal?: boolean;
  isBestSeller?: boolean;
  description?: string;
}

// Adding missing CartItem interface required by ShopContext
export interface CartItem extends Product {
  quantity: number;
}

// Adding missing AmbassadorStats interface required by ShopContext
export interface AmbassadorStats {
  clicks: number;
  conversions: number;
  earnings: number;
  referralCode: string;
}

export interface Review {
  id: string;
  user: string;
  rating: number;
  comment: string;
  avatar: string;
}