
import React, { useState, useEffect } from 'react';
import { Product, Review } from '../types';
import { useShop } from '../ShopContext';
import { GoogleGenAI, Type } from "@google/genai";

interface ProductCardProps {
  product: Product;
}

const ProductCard: React.FC<ProductCardProps> = ({ product }) => {
  const { wishlist, toggleWishlist, addToCart } = useShop();
  const [reviews, setReviews] = useState<Review[]>([]);
  const [isLoadingReviews, setIsLoadingReviews] = useState(false);
  
  const isWishlisted = wishlist.includes(product.id);

  const discountPercentage = product.oldPrice 
    ? Math.round(((product.oldPrice - product.price) / product.oldPrice) * 100) 
    : 0;

  useEffect(() => {
    const fetchProductReviews = async () => {
      setIsLoadingReviews(true);
      try {
        const ai = new GoogleGenAI({ apiKey: process.env.API_KEY });
        const response = await ai.models.generateContent({
          model: "gemini-3-flash-preview",
          contents: `Generate 3 high-end, realistic customer reviews for this product: ${product.name} (${product.category}). 
          The reviews should sound sophisticated and mention specific qualities of ${product.category}.`,
          config: {
            responseMimeType: "application/json",
            responseSchema: {
              type: Type.ARRAY,
              items: {
                type: Type.OBJECT,
                properties: {
                  id: { type: Type.STRING },
                  user: { type: Type.STRING },
                  rating: { type: Type.NUMBER },
                  comment: { type: Type.STRING },
                  avatar: { type: Type.STRING, description: "A high-quality avatar URL from unsplash or pravatar" }
                },
                required: ["id", "user", "rating", "comment", "avatar"]
              }
            }
          }
        });

        const data = JSON.parse(response.text || "[]");
        setReviews(data.slice(0, 3));
      } catch (error) {
        console.error("Failed to fetch reviews:", error);
      } finally {
        setIsLoadingReviews(false);
      }
    };

    fetchProductReviews();
  }, [product.name, product.category]);

  const handleBuyNow = () => {
    window.open(product.affiliateUrl, '_blank', 'noopener,noreferrer');
  };

  const handleToggleWishlist = (e: React.MouseEvent) => {
    e.stopPropagation();
    toggleWishlist(product.id);
  };

  const handleAddToCart = (e: React.MouseEvent) => {
    e.stopPropagation();
    addToCart(product);
  };

  return (
    <div className="group bg-white luxury-shadow transition-all duration-500 hover:-translate-y-2 border border-beige-100 flex flex-col h-full rounded-sm overflow-hidden relative">
      <div className="relative aspect-[3/4] overflow-hidden bg-beige-50">
        <img 
          src={product.image} 
          alt={product.name} 
          className="w-full h-full object-cover transition-transform duration-[2500ms] ease-out group-hover:scale-110" 
        />
        
        {/* Wishlist Button */}
        <button 
          onClick={handleToggleWishlist}
          className="absolute top-4 right-4 z-20 p-2 rounded-full bg-white/80 backdrop-blur-sm border border-beige-100 transition-all duration-300 hover:scale-110 active:scale-95"
          aria-label={isWishlisted ? "Remove from wishlist" : "Add to wishlist"}
        >
          <svg 
            className={`w-4 h-4 transition-colors duration-300 ${isWishlisted ? 'text-red-500 fill-current' : 'text-charcoal-400 fill-none'}`} 
            viewBox="0 0 24 24" 
            stroke="currentColor" 
            strokeWidth="2"
          >
            <path strokeLinecap="round" strokeLinejoin="round" d="M4.318 6.318a4.5 4.5 0 000 6.364L12 20.364l7.682-7.682a4.5 4.5 0 00-6.364-6.364L12 7.636l-1.318-1.318a4.5 4.5 0 00-6.364 0z" />
          </svg>
        </button>

        {/* Badges */}
        <div className="absolute top-4 left-4 z-10 flex flex-col gap-2">
          {discountPercentage > 0 && (
            <span className="bg-beige-900 text-white text-[9px] font-bold px-2 py-1 tracking-wider uppercase">
              {discountPercentage}% OFF
            </span>
          )}
          {product.isFlashDeal && <span className="bg-red-500 text-white text-[9px] font-bold px-2 py-1 tracking-wider uppercase">Flash Deal</span>}
          {product.isBestSeller && <span className="bg-charcoal-800 text-white text-[9px] font-bold px-2 py-1 tracking-wider uppercase">Elite Pick</span>}
        </div>

        {/* Affiliate Overlay */}
        <div className="absolute inset-0 bg-black/20 opacity-0 group-hover:opacity-100 transition-opacity duration-500 flex items-center justify-center p-6">
           <button 
             onClick={handleBuyNow}
             className="w-full py-4 bg-white text-charcoal-900 text-[10px] font-bold tracking-[0.3em] uppercase hover:bg-beige-50 transition-colors shadow-2xl"
           >
             Shop on {product.platform}
           </button>
        </div>
      </div>

      <div className="p-6 flex-grow flex flex-col">
        <div className="flex justify-between items-start mb-2">
          <p className="text-[9px] text-beige-800 font-bold tracking-[0.2em] uppercase">{product.category}</p>
          <div className="flex items-center text-yellow-500 text-[10px]">
            ★ <span className="text-gray-400 ml-1">{product.rating}</span>
          </div>
        </div>
        
        <h3 className="text-charcoal-900 font-serif text-lg mb-2 leading-tight group-hover:text-beige-800 transition-colors">{product.name}</h3>
        
        <div className="flex items-baseline gap-3 mb-6">
          <span className="text-charcoal-900 font-semibold text-lg">₹{product.price.toLocaleString('en-IN')}</span>
          {product.oldPrice && (
            <span className="text-gray-400 text-xs line-through">₹{product.oldPrice.toLocaleString('en-IN')}</span>
          )}
        </div>

        <div className="mt-auto space-y-2">
          <button 
            onClick={handleBuyNow}
            className="w-full py-3 border border-charcoal-900 text-charcoal-900 text-[9px] font-bold tracking-[0.2em] uppercase hover:bg-charcoal-900 hover:text-white transition-all duration-300"
          >
            Check Best Price
          </button>
          <button 
            onClick={handleAddToCart}
            className="w-full py-3 bg-charcoal-900 text-white text-[9px] font-bold tracking-[0.2em] uppercase hover:bg-charcoal-800 transition-all duration-300 shadow-md"
          >
            Add to Cart
          </button>
        </div>

        {/* AI-Powered Reviews Section */}
        <div className="mt-8 pt-6 border-t border-beige-100">
          <h4 className="text-[8px] font-bold tracking-[0.3em] uppercase text-beige-800 mb-4">Customer Reflections</h4>
          
          {isLoadingReviews ? (
            <div className="space-y-4 animate-pulse">
              {[1, 2].map((i) => (
                <div key={i} className="flex gap-3">
                  <div className="w-6 h-6 bg-beige-50 rounded-full" />
                  <div className="flex-1 space-y-1">
                    <div className="h-2 bg-beige-50 w-1/3 rounded" />
                    <div className="h-2 bg-beige-50 w-full rounded" />
                  </div>
                </div>
              ))}
            </div>
          ) : reviews.length > 0 ? (
            <div className="space-y-4">
              {reviews.map((review) => (
                <div key={review.id} className="group/review">
                  <div className="flex items-center gap-2 mb-1">
                    <img 
                      src={review.avatar} 
                      alt={review.user} 
                      className="w-5 h-5 rounded-full object-cover border border-beige-100 grayscale-[0.5] group-hover/review:grayscale-0 transition-all" 
                    />
                    <span className="text-[9px] font-bold text-charcoal-800">{review.user}</span>
                    <div className="ml-auto flex text-yellow-500 text-[7px]">
                      {[...Array(Math.floor(review.rating))].map((_, i) => <span key={i}>★</span>)}
                    </div>
                  </div>
                  <p className="text-[10px] text-gray-500 italic font-serif leading-relaxed line-clamp-2">
                    "{review.comment}"
                  </p>
                </div>
              ))}
            </div>
          ) : (
            <p className="text-[9px] text-gray-400 italic">No reflections yet for this piece.</p>
          )}
        </div>
      </div>
    </div>
  );
};

export default ProductCard;
